"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var utils_1 = require("./utils");
var AlbumTypes;
(function (AlbumTypes) {
    AlbumTypes[AlbumTypes["ALL"] = 0] = "ALL";
    AlbumTypes[AlbumTypes["FULL"] = 1] = "FULL";
    AlbumTypes[AlbumTypes["SINGLES"] = 2] = "SINGLES";
    AlbumTypes[AlbumTypes["OTHER"] = 3] = "OTHER";
})(AlbumTypes = exports.AlbumTypes || (exports.AlbumTypes = {}));
exports.melonAlbumsUrl = function (artistId) {
    var pageSize = 1000;
    var startIndex = 1;
    var queries = utils_1.makeParams({
        startIndex: startIndex,
        pageSize: pageSize,
        orderBy: "ISSUE_DATE",
        artistId: artistId,
    });
    return "artist/albumPaging.htm?" + queries;
};
exports.melonSongsUrl = function (artistId) {
    var pageSize = 1000;
    var startIndex = 1;
    var queries = utils_1.makeParams({
        pageSize: pageSize,
        startIndex: startIndex,
        orderBy: "ISSUE_DATE",
        artistId: artistId,
    });
    return "/artist/songPaging.htm?" + queries;
};
exports.melonSongLinkUrl = function (id) {
    return "https://www.melon.com/song/detail.htm?songId=" + id;
};
exports.melonAlbumLinkUrl = function (id) {
    return "https://www.melon.com/album/detail.htm?albumId=" + id;
};
exports.typeTranslations = {
    정규: "Album",
    싱글: "Single",
    EP: "EP",
    OST: "OST",
    옴니버스: "Omniverse",
    리믹스: "Remix",
    디지털: "Digital",
};
exports.extractSongs = function (album) {
    var rowSelector = "tbody tr";
    var rows = Array.from(album.querySelectorAll(rowSelector));
    return rows.map(function (row) {
        var _a, _b;
        var $ = row.querySelector.bind(row);
        var $$ = row.querySelectorAll.bind(row);
        var title = (_a = $("td + td.no + td.t_left a.btn")) === null || _a === void 0 ? void 0 : _a.textContent;
        var albumName = (_b = $("td + td.no + td.t_left + td + td a")) === null || _b === void 0 ? void 0 : _b.textContent;
        var isTitleTrack = Boolean($("span.title"));
        var allLinks = Array.from($$("td.t_left div div a")).map(extractHrefLink);
        var albumId = utils_1.findMap(allLinks, exports.matchAlbumId);
        var id = Number(utils_1.findMap(allLinks, exports.matchSongId));
        var melonUrl = id && exports.melonSongLinkUrl(id);
        return { title: title, albumName: albumName, isTitleTrack: isTitleTrack, albumId: albumId, id: id, melonUrl: melonUrl };
    });
};
exports.resolveType = function (str) {
    var _a, _b;
    var typeK = (_a = str.match(/\[(.*)\]/)) === null || _a === void 0 ? void 0 : _a[1];
    if (!typeK) {
        return "__unknown__";
    }
    return _b = exports.typeTranslations[typeK], (_b !== null && _b !== void 0 ? _b : typeK);
};
var extractHrefLink = function (elem) {
    var attr = "href";
    var jsLink = elem.getAttribute(attr);
    if (!jsLink) {
        throw Error("\n      Element that was expected to have an href js link\n      did not have an href attribute");
    }
    return jsLink;
};
var createIdMatcher = function (resource) { return function (doc) {
    var _a, _b;
    var matcher = new RegExp("go" + resource + "Detail\\((.*)\\)", "i");
    var quotedText = (_a = doc.match(matcher)) === null || _a === void 0 ? void 0 : _a[1];
    return Number((_b = quotedText) === null || _b === void 0 ? void 0 : _b.slice(1, -1));
}; };
exports.matchAlbumId = createIdMatcher("Album");
exports.matchSongId = createIdMatcher("Song");
exports.matchArtistId = createIdMatcher("Artist");
var extractAlbum = function (album) {
    var _a, _b, _c, _d, _e;
    var $ = album.querySelector.bind(album);
    var type = exports.resolveType((_b = (_a = $(".vdo_name")) === null || _a === void 0 ? void 0 : _a.textContent, (_b !== null && _b !== void 0 ? _b : "")));
    var releaseDate = (_c = $(".cnt_view")) === null || _c === void 0 ? void 0 : _c.textContent;
    var thumbnail = (_d = $(".thumb img")) === null || _d === void 0 ? void 0 : _d.getAttribute("src");
    var id = Number(exports.matchAlbumId($(".atist_info dt a").getAttribute("href")));
    var melonUrl = id && exports.melonAlbumLinkUrl(id);
    var name = (_e = $(".vdo_name + * + a")) === null || _e === void 0 ? void 0 : _e.textContent;
    return { type: type, releaseDate: releaseDate, thumbnail: thumbnail, melonUrl: melonUrl, name: name, id: id };
};
exports.extractAlbums = function (document) {
    var albums = Array.from(document.querySelectorAll(".d_album_list > ul > li"));
    return albums.map(extractAlbum);
};
//# sourceMappingURL=melon-resolvers.js.map