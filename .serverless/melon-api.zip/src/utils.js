"use strict";
var __spreadArrays = (this && this.__spreadArrays) || function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeParams = function (params) {
    return Object.entries(params)
        .map(function (_a) {
        var k = _a[0], v = _a[1];
        return k + "=" + v;
    })
        .join("&");
};
exports.filterMap = function (elements, f) {
    return elements.reduce(function (acc, elem) {
        var result = f(elem);
        if (!result) {
            return acc;
        }
        return __spreadArrays(acc, [result]);
    }, []);
};
exports.findMap = function (elements, f) {
    var out = elements.find(f);
    if (out) {
        return f(out);
    }
};
//# sourceMappingURL=utils.js.map