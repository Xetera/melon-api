"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var winston = require("winston");
var isProd = process.env.NODE_ENV === "production";
var format = winston.format.combine(winston.format.colorize(), winston.format.align(), winston.format.simple());
var transportConsole = new winston.transports.Console({ format: format });
exports.logger = winston.createLogger({
    level: isProd ? "error" : "debug",
    transports: [transportConsole],
});
//# sourceMappingURL=logger.js.map