var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'xetera',
applicationName: 'melon-api',
appUid: '79sb0vft83m8B3RckK',
tenantUid: 'N7LqgLzK3z8f7s4nHX',
deploymentUid: 'bf3ec6dd-9d88-4a41-a924-cd6b8851f349',
serviceName: 'melon-api',
stageName: 'dev'})
const handlerWrapperArgs = { functionName: 'melon-api-dev-graphql', timeout: 6}
try {
  const userHandler = require('./src/index.js')
  module.exports.handler = serverlessSDK.handler(userHandler.server, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
